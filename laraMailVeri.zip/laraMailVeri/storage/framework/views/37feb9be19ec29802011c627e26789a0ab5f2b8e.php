<table class="subcopy" width="100%" cellpadding="0" cellspacing="0">
    <tr>
        <td>
            <?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

        </td>
    </tr>
</table>

<?php /* /Users/hardikparsania_mac/Desktop/web_demonuts/laraEmailVeri/laraMailVeri/vendor/laravel/framework/src/Illuminate/Mail/resources/views/html/subcopy.blade.php */ ?>