[<?php echo e($slot); ?>](<?php echo e($url); ?>)

<?php /* /Users/hardikparsania_mac/Desktop/web_demonuts/laraEmailVeri/laraMailVeri/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php */ ?>